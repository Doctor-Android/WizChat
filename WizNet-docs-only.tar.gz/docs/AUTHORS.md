reflect-metadata is authored by:
* Cy Brown
* Oleh Dokuka
* Ron Buckton
* William Buchwalter