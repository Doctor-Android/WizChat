# WizNet Project Structure

## 📁 Directory Overview

```
WizNet-Release/
├── assets/                          # Project assets (logos, icons)
│   └── README.md                   # Asset specifications
├── include/                         # Header files
│   ├── core/                       # Core functionality headers
│   ├── network/                    # Network service headers
│   └── ui/                         # User interface headers
├── scripts/                        # Build and deployment scripts
│   └── release-package.sh          # Cross-platform packaging
├── src/                            # Source code
│   ├── core/                       # Core functionality
│   ├── network/                    # Network services
│   ├── ui/                         # User interface
│   └── wiznet-cli.cpp             # Main CLI application
├── .github/                        # GitHub-specific files
│   └── README.md                   # GitHub setup guide
├── .gitignore                      # Git ignore rules
├── CMakeLists.txt                  # CMake build configuration
├── LICENSE                         # RamonRamos License v1.0
├── LICENSE_RAMONRAMOS.md           # Detailed license terms
├── PROJECT_STRUCTURE.md            # This file
└── README.md                       # Main project documentation
```

## 🔧 Core Components

### Source Code (src/)
- **wiznet-cli.cpp**: Main CLI interface with all commands
- **core/**: Core functionality and utilities
- **network/**: Mesh networking, Bluetooth, WiFi services
- **ui/**: User interface components

### Headers (include/)
- **core/**: Core functionality headers
- **network/**: Network service headers
- **ui/**: User interface headers

### Scripts (scripts/)
- **release-package.sh**: Cross-platform build and packaging

## 🎯 Cross-Platform Support

### Windows 11
- Native Windows API integration
- Bluetooth and WiFi support
- Audio playback system
- Process management

### macOS
- Core Foundation integration
- IOKit for hardware access
- Audio framework support
- Network framework

### Linux (All Distributions)
- BlueZ Bluetooth stack
- NetworkManager integration
- ALSA/PulseAudio support
- Systemd integration

## 📦 Build System

### CMake Configuration
- Cross-platform build support
- Dependency management
- Platform-specific optimizations
- Release packaging

### Dependencies
- C++17 compiler
- libcurl (networking)
- OpenSSL (security)
- SQLite3 (storage)
- Platform-specific libraries

## 🚀 Current Functionality

### ✅ Working Features
- Cross-platform CLI with real functionality
- Bluetooth mesh networking
- WiFi mesh networking
- Internet sharing between nodes
- BitChat messaging (groups, DMs)
- Tor network integration
- qBittorrent client control
- Multi-source music playback
- Network scanning and diagnostics
- Configuration management

### 🔄 In Development
- GUI interfaces
- Mobile app versions
- Advanced mesh routing
- Blockchain integration
- AI-powered features

## 📄 License Information

- **License**: RamonRamos License v1.0
- **Owner**: Julio Montesino Torres
- **Options**: 20 USD commercial or 10% revenue share
- **Attribution**: Required for open source use

## 🎯 Release Status

**Status**: ✅ Ready for Release
**Version**: 1.0.0
**Platforms**: Windows 11, macOS, Linux
**License**: RamonRamos License v1.0

---

*This project structure represents a complete, cross-platform mesh networking solution with real functionality across all major operating systems.*
