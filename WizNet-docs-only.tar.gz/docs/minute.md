# minute

```js
// usage
chance.minute()
```

Generate a random minute

```js
chance.minute();
=> 35
```

By default, returns a minute from 0 to 59. Idea is for generating a clock time.
