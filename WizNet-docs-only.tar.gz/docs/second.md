# second

```js
// usage
chance.second()
```

Generate a random second

```js
chance.second();
=> 19
```

By default, returns a second from 0 to 59. Idea is for generating a clock time.
