# fbid

```js
// usage
chance.fbid()
```

Return a random Facebook id, aka fbid.

```js
chance.fbid()
=> "1000039460258605"
```
