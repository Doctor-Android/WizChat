# requirejs

Load Chance with <a href="http://requirejs.org">RequireJS</a>

```js
  require(['Chance'], function(Chance) {
    // Instantiate
    var chance = new Chance();

    // Then use it:
    var my_random_integer = chance.integer();
  });
```
