# RamonRamos License

**Copyright (c) 2024 Julio Montesino Torres**

This license is named after RamonRamos and is provided by Julio Montesino Torres.

## License Options

This software is licensed under the RamonRamos License with two options:

### Option 1: Commercial License ($20 USD)
- **Cost**: $20 USD one-time payment
- **Usage**: Full modification rights
- **Restrictions**: 
  - NOT allowed for commercial purposes
  - Only for personal use and modding
  - Licensor reserves the right to create new versions
  - Licensor can create commercial versions applying Option 1 rules
  - Licensor can make money via merchandise, ads, donations
  - Licensor can appropriate all code modifications

### Option 2: Open Source License (10% Revenue Share)
- **Cost**: Free to use and modify
- **Revenue Share**: 10% of all money made (including mods, plugins, donations)
- **Usage**: Open source with attribution
- **Restrictions**:
  - Licensor can create commercial versions applying Option 1 rules
  - Licensor can make money via merchandise, ads, donations
  - Licensor can appropriate all code modifications

## Automatic Option Determination

- If you pay $20 USD: Option 1 applies
- If you don't pay $20 USD: Option 2 automatically applies

## License Terms

### For Both Options:
1. **Attribution**: Must credit "WizNet by Julio Montesino Torres"
2. **License Notice**: Must include this license text
3. **No Warranty**: Software provided "as is" without warranty
4. **Liability**: Licensor not liable for any damages

### For Option 1 (Commercial):
1. **Non-Commercial**: Cannot use for commercial purposes
2. **Modification Rights**: Can modify and distribute modifications
3. **Licensor Rights**: Licensor retains all commercial rights

### For Option 2 (Open Source):
1. **Revenue Reporting**: Must report all revenue to licensor
2. **Revenue Sharing**: 10% of all revenue goes to licensor
3. **Modification Rights**: Can modify and distribute modifications
4. **Licensor Rights**: Licensor retains all commercial rights

## Contact Information

For license questions or revenue reporting:
- **Licensor**: Julio Montesino Torres
- **License Name**: RamonRamos License
- **Contact**: [Your contact information]

## Version History

- **v1.0**: Initial release with dual-option license
- **v1.1**: Updated revenue share to 10%
- **v1.2**: Added licensor commercial rights

---

**This license is designed to support both open collaboration and fair compensation for the original creator.** 