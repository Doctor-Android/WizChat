# WizNet CLI linux Installation

## Quick Start
1. Extract this package
2. Open terminal/command prompt
3. Run: ./wiznet-cli (Linux/macOS) or wiznet-cli.exe (Windows)
4. Type 'help' for available commands

## Dependencies
- No additional dependencies required (all included)

## Features
- Mesh networking
- Tor integration
- qBittorrent management
- Music playback
- Browser control
- Network scanning (Bluetooth/WiFi)
- Chat system
- Configuration management

## Support
- GitHub: https://github.com/wiznet/wiznet-cli
- Documentation: README_CLI.md
- Issues: GitHub Issues

## License
See LICENSE file for details.
