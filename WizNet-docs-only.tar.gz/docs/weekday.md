# weekday

```js
// usage
chance.weekday()
chance.weekday({weekday_only: true})
```

Return a weekday

```js
chance.weekday();
=> 'Tuesday'
```

By default, weekday_only is false. If set to true it will never return Saturday or Sunday.
