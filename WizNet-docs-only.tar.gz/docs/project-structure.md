# HiveMind Project Structure

## Core Extension Files
- `/manifest.json` - Extension manifest file
- `/background.js` - Extension background script for network management
- `/popup/` - Extension popup UI
  - `popup.html` - Main popup HTML
  - `popup.js` - Popup functionality
  - `popup.css` - Popup styling
- `/options/` - Extension options page
  - `options.html` - Options page HTML
  - `options.js` - Options page scripts
  - `options.css` - Options page styling

## Network Features
- `/lib/` - Core libraries
  - `hivemind.js` - Main HiveMind class implementation
  - `network.js` - Network management functionality
  - `p2p.js` - Peer-to-peer connection handling
  - `ipfs-handler.js` - IPFS integration for distributed content
  - `tor-connector.js` - Tor integration for anonymous routing
  - `encryption.js` - End-to-end encryption utilities
  - `user-manager.js` - User management and authentication

## UI Components
- `/components/` - Reusable UI components
  - `dashboard/` - Network dashboard components
  - `messenger/` - Chat system components
  - `website-manager/` - Website hosting components
  - `profile-editor/` - User profile components
  - `network-browser/` - Network discovery components

## Resources
- `/assets/` - Static assets
  - `icons/` - Extension and UI icons
  - `themes/` - Custom theme files
  - `templates/` - Website templates for the site builder

## Services
- `/services/` - Background services
  - `signaling-service.js` - WebRTC signaling
  - `storage-service.js` - Data persistence
  - `notification-service.js` - User notifications

## Utils
- `/utils/` - Utility functions
  - `permissions.js` - Role-based access control
  - `validation.js` - Input validation
  - `logging.js` - Error logging and diagnostics
  - `auth.js` - Authentication utilities

## Testing
- `/tests/` - Test files for components and services

## Documentation
- `/docs/` - Documentation files
  - `api.md` - API documentation
  - `user-guide.md` - User manual
  - `admin-guide.md` - Network administration guide
  - `developer-guide.md` - Extension development guide 