# RamonRamos License v1.0

**Copyright (c) 2025 Julio Montesino Torres. All rights reserved.**
**License named in honor of RamonRamos.**

## License Terms

This license applies to all products and software developed by Julio Montesino Torres ("Licensor") that are made available to the public.

**IMPORTANT: License Option Determination**
- If a product is **charged at exactly 20 USD** → Option 1 applies
- If a product is **modifiable but NOT charged at 20 USD** → Option 2 automatically applies
- If a product is **free and modifiable** → Option 2 automatically applies

### Option 1: Commercial License (20 USD)
For products that are **charged at exactly 20 USD**:

- **Full Modification Rights**: Licensee may fully modify, adapt, and customize the product
- **Personal Use Only**: Licensee may NOT use for commercial purposes
- **Redistribution**: Licensee may redistribute modified versions (free or for charge)
- **No Royalties**: No ongoing royalties or fees beyond the initial 20 USD payment
- **Warranty**: Product provided "as-is" without warranty
- **Licensor Rights**: Licensor reserves the right to create new versions of the product

### Option 2: Open Source License (10% Revenue Share)
For products that are **modifiable but NOT charged at 20 USD** (including free products):

- **Open Source**: Source code is freely available and modifiable
- **Revenue Sharing**: Any money made including:
  - Modifications and plugins
  - Donations
  - Commercial derivatives
  - Premium features
  - Support services
  - **Flat 10%** of all revenue must be shared with Licensor
- **Attribution**: Original work must be attributed to Julio Montesino Torres
- **License Continuity**: Modified versions must maintain this license
- **Licensor Rights**: Licensor reserves the right to create new versions of the product

## Licensor Commercial Rights (Option 2 Products)

For products under Option 2, Licensor reserves the following rights:

### Commercial Version Rights
- **Commercial Versions**: Licensor may create commercial versions applying Option 1 rules
- **Merchandise**: Licensor may create and sell merchandise related to the product
- **Advertising**: Licensor may monetize through advertisements, sponsorships, etc.
- **Donations**: Licensor may receive donations (Patreon, etc.) without revenue sharing
- **Premium Features**: Licensor may create premium versions without revenue sharing

### Code Appropriation Rights
- **All Modifications**: Licensor may appropriate and use all code modifications
- **Forking Rights**: Licensor may fork any modified versions
- **Integration Rights**: Licensor may integrate any modifications into new versions
- **No Attribution Required**: Licensor is not required to attribute modifications to original authors
- **Commercial Use**: Licensor may use all modifications for commercial purposes

## Revenue Reporting Requirements

For Option 2 products:
- Licensee must report all revenue quarterly
- 10% payment due within 30 days of quarter end
- Failure to report or pay constitutes license violation
- Licensor reserves right to audit revenue records

## Enforcement

- Violation of license terms results in immediate termination
- Licensor may pursue legal action for violations
- Injunctive relief available for continued violations
- Attorney fees recoverable by prevailing party

## Governing Law

This license is governed by the laws of the jurisdiction where Licensor is located.

## Contact

For questions about this license, contact Julio Montesino Torres at the provided contact information.

---

**RamonRamos License v1.0 - Effective Date: 2025**
**Owner: Julio Montesino Torres**
**Named in honor of: RamonRamos**

*This license is designed to support both commercial and open-source development while ensuring fair compensation for the original creator.* 