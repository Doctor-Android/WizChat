# hashtag

```js
// usage
chance.hashtag()
```

Return a random hashtag. This is a string of the form '#thisisahashtag'.

```js
chance.hashtag()
=> '#dichumwa'
```
