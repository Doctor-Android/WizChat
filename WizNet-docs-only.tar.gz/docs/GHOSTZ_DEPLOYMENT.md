# Ghostz Deployment Guide

## Quick Start

### Prerequisites
- Xcode 15.0+ (for iOS/macOS development)
- Node.js 18.0+ (for browser extension)
- Brave Browser (for extension testing)
- Physical iOS devices (for mesh networking)

### 1. Clone and Setup

```bash
# Clone the Ghostz repository
git clone https://github.com/yourusername/ghostz.git
cd ghostz

# Install dependencies
npm install

# Generate Xcode project
xcodegen generate

# Open in Xcode
open ghostz.xcodeproj
```

### 2. Build and Run

```bash
# Build for iOS
xcodebuild -project ghostz.xcodeproj -scheme "Ghostz (iOS)" -destination 'platform=iOS Simulator,name=iPhone 15' build

# Build for macOS
xcodebuild -project ghostz.xcodeproj -scheme "Ghostz (macOS)" build

# Build browser extension
npm run build:extension
```

## Configuration

### 1. Network Configuration

```swift
// GhostzConfig.swift
struct GhostzConfig {
    // Mesh Network Settings
    static let meshServiceUUID = CBUUID(string: "F47B5E2D-4A9E-4C5A-9B3F-8E1D2C3A4B5C")
    static let meshCharacteristicUUID = CBUUID(string: "A1B2C3D4-E5F6-4A5B-8C9D-0E1F2A3B4C5D")
    
    // WiFi Sharing Settings
    static let maxWiFiConnections = 10
    static let wifiSharingTimeout: TimeInterval = 300 // 5 minutes
    static let enableWiFiEncryption = true
    
    // Addiction Prevention Settings
    static let maxSessionTime: TimeInterval = 3600 // 1 hour
    static let breakTime: TimeInterval = 1800 // 30 minutes
    static let enableTimers = true
    
    // Admin Settings
    static let requireAdminAuth = true
    static let enableTorRouting = true
    static let enableContentFiltering = false
}
```

### 2. Browser Extension Configuration

```javascript
// extension-config.js
const GhostzConfig = {
    // Brave Integration
    braveIntegration: {
        enabled: true,
        privacyLevel: 'aggressive',
        enableTor: true,
        enableShields: true
    },
    
    // Tor Configuration
    tor: {
        enabled: true,
        socksPort: 9050,
        controlPort: 9051,
        dataDirectory: '/tmp/ghostz-tor',
        bridges: []
    },
    
    // Addiction Prevention
    addictionPrevention: {
        enabled: true,
        sessionLimit: 3600, // 1 hour
        breakTime: 1800,    // 30 minutes
        features: {
            gaming: { maxTime: 1800, cooldown: 900 },
            browsing: { maxTime: 2400, cooldown: 1200 },
            video: { maxTime: 1200, cooldown: 600 },
            social: { maxTime: 1800, cooldown: 900 }
        }
    },
    
    // Admin Settings
    admin: {
        requireAuth: true,
        permissions: ['user_management', 'network_configuration', 'content_moderation'],
        defaultAdmin: {
            username: 'admin',
            password: 'changeme123'
        }
    }
};
```

## Deployment Steps

### Phase 1: Core App Deployment

#### 1. iOS App Store Deployment

```bash
# Archive the app
xcodebuild -project ghostz.xcodeproj -scheme "Ghostz (iOS)" -configuration Release -archivePath build/Ghostz.xcarchive archive

# Export for App Store
xcodebuild -exportArchive -archivePath build/Ghostz.xcarchive -exportOptionsPlist exportOptions.plist -exportPath build/AppStore

# Upload to App Store Connect
xcrun altool --upload-app --type ios --file build/AppStore/Ghostz.ipa --username "your-apple-id" --password "app-specific-password"
```

#### 2. macOS App Store Deployment

```bash
# Archive for macOS
xcodebuild -project ghostz.xcodeproj -scheme "Ghostz (macOS)" -configuration Release -archivePath build/Ghostz-macOS.xcarchive archive

# Export for Mac App Store
xcodebuild -exportArchive -archivePath build/Ghostz-macOS.xcarchive -exportOptionsPlist exportOptions-macOS.plist -exportPath build/MacAppStore
```

### Phase 2: Browser Extension Deployment

#### 1. Chrome Web Store

```bash
# Build extension
npm run build:extension

# Create ZIP file
cd dist/extension
zip -r ghostz-extension.zip .

# Upload to Chrome Web Store Developer Dashboard
# https://chrome.google.com/webstore/devconsole
```

#### 2. Direct Distribution

```bash
# Create distribution package
npm run package:extension

# The extension will be available at:
# dist/ghostz-extension.crx
```

### Phase 3: Server Components

#### 1. Signaling Server Deployment

```bash
# Deploy to cloud provider (AWS, Google Cloud, etc.)
cd server/signaling
npm install
npm run build

# Deploy with PM2
pm2 start ecosystem.config.js
```

#### 2. Tor Relay Setup

```bash
# Install Tor
sudo apt-get install tor

# Configure Tor for Ghostz
sudo cp config/torrc /etc/tor/torrc
sudo systemctl restart tor
```

## Configuration Files

### 1. iOS App Configuration

```xml
<!-- Info.plist additions -->
<key>NSBluetoothAlwaysUsageDescription</key>
<string>Ghostz uses Bluetooth to create a distributed WiFi network with nearby users.</string>
<key>NSBluetoothPeripheralUsageDescription</key>
<string>Ghostz uses Bluetooth to discover and connect with other Ghostz users nearby.</string>
<key>UIBackgroundModes</key>
<array>
    <string>bluetooth-central</string>
    <string>bluetooth-peripheral</string>
</array>
```

### 2. Browser Extension Manifest

```json
{
  "manifest_version": 3,
  "name": "Ghostz",
  "version": "1.0.0",
  "description": "Distributed WiFi network with addiction prevention",
  "permissions": [
    "storage",
    "tabs",
    "webNavigation",
    "webRequest",
    "proxy",
    "notifications",
    "identity"
  ],
  "host_permissions": [
    "<all_urls>"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "action": {
    "default_popup": "popup.html"
  }
}
```

### 3. Server Configuration

```javascript
// server-config.js
module.exports = {
    port: process.env.PORT || 3000,
    tor: {
        enabled: process.env.TOR_ENABLED === 'true',
        socksPort: 9050,
        controlPort: 9051
    },
    mesh: {
        maxConnections: 50,
        heartbeatInterval: 30000,
        timeout: 60000
    },
    admin: {
        requireAuth: true,
        sessionTimeout: 3600000 // 1 hour
    }
};
```

## Security Considerations

### 1. Encryption

```swift
// SecurityManager.swift
class SecurityManager {
    static let shared = SecurityManager()
    
    // Use strong encryption for all communications
    private let encryptionKey = SymmetricKey(size: .bits256)
    
    func encryptWiFiCredentials(_ credentials: WiFiCredentials) -> Data {
        let sealedBox = try! AES.GCM.seal(credentials.encode(), using: encryptionKey)
        return sealedBox.combined!
    }
    
    func decryptWiFiCredentials(_ encryptedData: Data) -> WiFiCredentials? {
        let sealedBox = try! AES.GCM.SealedBox(combined: encryptedData)
        let decryptedData = try! AES.GCM.open(sealedBox, using: encryptionKey)
        return WiFiCredentials.decode(from: decryptedData)
    }
}
```

### 2. Admin Authentication

```swift
// AdminAuthManager.swift
class AdminAuthManager {
    func authenticateAdmin(username: String, password: String) -> Bool {
        // Use secure password hashing
        let hashedPassword = hashPassword(password, salt: getSalt())
        return verifyPassword(username, hashedPassword)
    }
    
    private func hashPassword(_ password: String, salt: Data) -> Data {
        // Use Argon2id for password hashing
        return try! Argon2.hash(password: password, salt: salt)
    }
}
```

### 3. Network Security

```swift
// NetworkSecurityManager.swift
class NetworkSecurityManager {
    func validateWiFiRequest(_ request: WiFiAccessRequest) -> Bool {
        // Validate request origin
        guard isValidPeer(request.requester) else { return false }
        
        // Check rate limiting
        guard !isRateLimited(request.requester) else { return false }
        
        // Validate network permissions
        guard hasNetworkPermission(request.requester, network: request.networkSSID) else { return false }
        
        return true
    }
}
```

## Monitoring and Analytics

### 1. Usage Analytics

```swift
// AnalyticsManager.swift
class AnalyticsManager {
    func trackFeatureUsage(_ feature: String, duration: TimeInterval) {
        let event = AnalyticsEvent(
            type: "feature_usage",
            feature: feature,
            duration: duration,
            timestamp: Date()
        )
        
        // Send to analytics service (privacy-preserving)
        sendAnalyticsEvent(event)
    }
    
    func trackAddictionPrevention(_ action: String) {
        let event = AnalyticsEvent(
            type: "addiction_prevention",
            action: action,
            timestamp: Date()
        )
        
        sendAnalyticsEvent(event)
    }
}
```

### 2. Network Monitoring

```swift
// NetworkMonitor.swift
class NetworkMonitor {
    func monitorMeshNetwork() {
        // Monitor network health
        let health = MeshNetworkHealth(
            activePeers: meshService.connectedPeers.count,
            sharedNetworks: wifiManager.sharedNetworks.count,
            totalConnections: wifiManager.totalConnections
        )
        
        // Send health metrics
        sendHealthMetrics(health)
    }
}
```

## Distribution Channels

### 1. App Store Distribution

- **iOS App Store**: Submit through App Store Connect
- **Mac App Store**: Submit through App Store Connect
- **Chrome Web Store**: Submit through Chrome Web Store Developer Dashboard

### 2. Direct Distribution

- **iOS**: Enterprise distribution or TestFlight
- **macOS**: Direct download from website
- **Browser Extension**: Direct download and sideloading

### 3. Open Source Distribution

- **GitHub**: Source code and releases
- **Package Managers**: Homebrew, Chocolatey
- **Linux**: Snap, Flatpak, AppImage

## Maintenance and Updates

### 1. Automated Updates

```swift
// UpdateManager.swift
class UpdateManager {
    func checkForUpdates() {
        // Check for app updates
        checkAppUpdates()
        
        // Check for extension updates
        checkExtensionUpdates()
        
        // Check for server updates
        checkServerUpdates()
    }
    
    func performUpdate(_ update: Update) {
        // Download update
        downloadUpdate(update)
        
        // Verify update integrity
        verifyUpdateIntegrity(update)
        
        // Install update
        installUpdate(update)
    }
}
```

### 2. Backup and Recovery

```swift
// BackupManager.swift
class BackupManager {
    func backupUserData() {
        // Backup user preferences
        backupPreferences()
        
        // Backup network configurations
        backupNetworkConfigs()
        
        // Backup admin settings
        backupAdminSettings()
    }
    
    func restoreUserData() {
        // Restore from backup
        restoreFromBackup()
    }
}
```

## Troubleshooting

### Common Issues

1. **Bluetooth Not Working**
   - Ensure Bluetooth is enabled
   - Check app permissions
   - Restart the app

2. **WiFi Sharing Not Working**
   - Check network permissions
   - Verify admin settings
   - Check firewall settings

3. **Addiction Prevention Not Working**
   - Check timer settings
   - Verify admin permissions
   - Restart the app

4. **Browser Extension Issues**
   - Check Brave browser compatibility
   - Verify extension permissions
   - Reinstall the extension

### Debug Mode

```swift
// Enable debug mode
#if DEBUG
    GhostzConfig.enableDebugMode = true
    GhostzConfig.logLevel = .verbose
#endif
```

## Performance Optimization

### 1. Memory Management

```swift
// MemoryManager.swift
class MemoryManager {
    func optimizeMemoryUsage() {
        // Clear old messages
        clearOldMessages()
        
        // Optimize image cache
        optimizeImageCache()
        
        // Clear temporary files
        clearTempFiles()
    }
}
```

### 2. Battery Optimization

```swift
// BatteryOptimizer.swift
class BatteryOptimizer {
    func optimizeForBattery() {
        // Reduce Bluetooth scanning frequency
        reduceBluetoothScanning()
        
        // Optimize WiFi sharing
        optimizeWiFiSharing()
        
        // Reduce background processing
        reduceBackgroundProcessing()
    }
}
```

This deployment guide provides comprehensive instructions for deploying Ghostz across all platforms while maintaining security, performance, and user experience. 