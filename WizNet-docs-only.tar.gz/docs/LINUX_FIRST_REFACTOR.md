# WizNet Linux-First Refactoring Plan

## Current State Analysis

### Existing Linux Components
- ✅ GTK-based Linux application (`Sources/Linux/`)
- ✅ NixonCore integration
- ✅ Platform adapter pattern
- ✅ Music player and theme management
- ✅ Systemd-ready architecture

### Android Issues to Resolve
- ❌ Type mismatches between ViewModel and UI data classes
- ❌ Chip component compatibility issues
- ❌ Missing imports and references
- ❌ Weight function compilation errors

## Refactoring Strategy

### Phase 1: Linux Core Enhancement (Immediate)
1. **Enhance Linux Core Services**
   - Expand NixonCore for Linux-specific features
   - Add systemd service integration
   - Implement Arch package manager integration
   - Add terminal-first interface

2. **Linux Build System**
   - CMake-based build system
   - AUR package creation
   - Systemd service files
   - Desktop integration

### Phase 2: Cross-Platform Library
1. **Shared Core Library**
   - Extract common functionality
   - Platform-agnostic interfaces
   - Shared data models
   - Common algorithms

2. **Platform-Specific Adapters**
   - Linux: GTK/Qt native
   - Windows: Win32/WPF
   - macOS: Cocoa/SwiftUI
   - Mobile: Platform-specific UI

### Phase 3: Mobile Platform Cleanup
1. **Android Refinement**
   - Fix current build issues
   - Simplify to companion app
   - Remove complex features
   - Focus on core functionality

2. **iOS Development**
   - Minimal feature set
   - App Store compliance
   - Core functionality only

## Implementation Plan

### Step 1: Fix Android Build Issues
- [ ] Resolve type mismatches
- [ ] Fix Chip component issues
- [ ] Add missing imports
- [ ] Correct weight function usage
- [ ] Simplify Android feature set

### Step 2: Enhance Linux Core
- [ ] Expand NixonCore for Linux
- [ ] Add systemd service files
- [ ] Create AUR package
- [ ] Add terminal interface
- [ ] Implement Arch-specific features

### Step 3: Create Shared Library
- [ ] Extract common data models
- [ ] Create platform-agnostic interfaces
- [ ] Implement shared algorithms
- [ ] Design cross-platform architecture

### Step 4: Platform-Specific UI
- [ ] Linux: GTK/Qt native UI
- [ ] Windows: Win32/WPF UI
- [ ] macOS: Cocoa/SwiftUI
- [ ] Mobile: Simplified UI

## Technical Architecture

### Linux (Primary)
```
Sources/Linux/
├── main.cpp              # Main application entry
├── MainWindow.h          # GTK main window
├── services/             # Linux-specific services
│   ├── SystemdService.h
│   ├── PackageManager.h
│   └── TerminalInterface.h
├── ui/                   # Linux UI components
│   ├── GtkInterface.h
│   └── QtInterface.h
└── build/                # Build system
    ├── CMakeLists.txt
    ├── wiznet.service    # Systemd service
    └── PKGBUILD          # AUR package
```

### Shared Core
```
Sources/Core/
├── NixonCore.h           # Core functionality
├── data/                 # Shared data models
├── algorithms/           # Shared algorithms
├── services/             # Platform-agnostic services
└── interfaces/           # Platform interfaces
```

### Platform Adapters
```
Sources/
├── Linux/                # Linux implementation
├── Windows/              # Windows implementation
├── macOS/                # macOS implementation
├── Android/              # Android implementation
└── iOS/                  # iOS implementation
```

## Build System Priority

### 1. Linux Build (Primary)
```bash
# Arch Linux
mkdir build && cd build
cmake ..
make
sudo make install

# AUR Package
makepkg -si
```

### 2. Cross-Platform Build
```bash
# Linux
cmake -DPLATFORM=linux ..
make

# Windows
cmake -DPLATFORM=windows ..
make

# macOS
cmake -DPLATFORM=macos ..
make
```

### 3. Mobile Builds (Tertiary)
```bash
# Android
./gradlew build

# iOS
xcodebuild -project WizNet.xcodeproj
```

## Development Workflow

### Linux-First Development
1. **Feature Development**: Implement on Linux first
2. **Testing**: Test on Arch Linux primarily
3. **Cross-Platform**: Adapt to other platforms
4. **Mobile**: Simplify for mobile platforms

### Priority Order
1. **Linux (Arch-based)** - Full feature set
2. **Linux (Other distros)** - Full feature set
3. **Windows/macOS** - Core features
4. **Android** - Companion features
5. **iOS** - Minimal features

## Next Steps

### Immediate (This Session)
1. Fix Android build issues
2. Create Linux-first documentation
3. Plan shared library structure

### Short Term (Next Week)
1. Enhance Linux core services
2. Create systemd service files
3. Build AUR package
4. Add terminal interface

### Medium Term (Next Month)
1. Extract shared core library
2. Create platform adapters
3. Implement cross-platform UI
4. Simplify mobile platforms

### Long Term (Next Quarter)
1. Full Linux ecosystem integration
2. Cross-platform feature parity
3. Mobile platform optimization
4. Community package distribution 