# currency

```js
// usage
chance.currency()
```

Generate a random currency.

```js
chance.currency();
=> { code: "TVD", name: "Tuvalu Dollar" }
```
