# city

```js
// usage
chance.city()
```

Generate a random city name

```js
chance.city();
=> 'Cowotba'
```
