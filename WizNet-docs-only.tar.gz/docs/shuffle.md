# shuffle

```js
// usage
chance.shuffle(array)
```

Given an array, scramble the order and return it.

```js
chance.shuffle(['alpha', 'bravo', 'charlie', 'delta', 'echo']);
=> ['echo', 'delta', 'alpha', 'charlie', 'bravo']
```
