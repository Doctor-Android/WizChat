# ip

```js
// usage
chance.ip()
```

Return a random IP Address.

```js
chance.ip()
=> '153.208.102.234'
```

