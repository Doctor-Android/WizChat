# Contributing to WizNet

Thank you for your interest in contributing to WizNet! This document provides guidelines and information for contributors.

## 🤝 How to Contribute

### Reporting Issues

Before creating bug reports, please check the existing issues to avoid duplicates.

**Bug Report Template:**
```
**Description:**
A clear description of what the bug is.

**Steps to Reproduce:**
1. Go to '...'
2. Click on '...'
3. See error

**Expected Behavior:**
What you expected to happen.

**Actual Behavior:**
What actually happened.

**Environment:**
- OS: [e.g. Ubuntu 20.04]
- Compiler: [e.g. GCC 9.4.0]
- Version: [e.g. 1.0.0]

**Additional Context:**
Any other context about the problem.
```

### Feature Requests

We welcome feature requests! Please describe the feature and explain why it would be useful.

### Code Contributions

#### Development Setup

1. **Fork the repository**
2. **Clone your fork:**
   ```bash
   git clone https://github.com/yourusername/wiznet.git
   cd wiznet
   ```

3. **Create a feature branch:**
   ```bash
   git checkout -b feature/your-feature-name
   ```

4. **Make your changes and test:**
   ```bash
   mkdir build && cd build
   cmake ..
   make -j4
   ./wiznet
   ```

5. **Commit your changes:**
   ```bash
   git add .
   git commit -m "Add: descriptive commit message"
   ```

6. **Push to your fork:**
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Create a Pull Request**

#### Coding Standards

- **C++17**: Use modern C++ features
- **Naming**: Use descriptive names for variables and functions
- **Comments**: Add comments for complex logic
- **Formatting**: Follow the existing code style
- **Testing**: Test your changes thoroughly

#### Code Style Guidelines

```cpp
// Good: Clear, descriptive names
class MeshNetworkService {
private:
    std::map<std::string, Node> networkNodes;
    std::mutex networkMutex;
    
public:
    void addNode(const std::string& nodeId, const std::string& address) {
        std::lock_guard<std::mutex> lock(networkMutex);
        // Implementation
    }
};

// Good: Proper error handling
void processData(const std::string& data) {
    if (data.empty()) {
        std::cerr << "Error: Empty data provided" << std::endl;
        return;
    }
    // Process data
}
```

### Documentation

- Update README.md if you add new features
- Add comments to complex code sections
- Update any relevant documentation

### Testing

Before submitting a PR, please ensure:

- [ ] Code compiles without warnings
- [ ] All tests pass (if applicable)
- [ ] New features are tested
- [ ] No memory leaks
- [ ] Thread safety is maintained

## 🏗️ Project Structure

```
WizNet/
├── src/
│   └── core/
│       └── wiznet_complete_system.cpp  # Main system
├── include/                            # Headers
├── CMakeLists.txt                     # Build config
├── README.md                          # Main documentation
├── LICENSE                            # MIT License
├── CONTRIBUTING.md                    # This file
└── build/                             # Build output
```

## 🎯 Areas for Contribution

### High Priority
- **Performance optimizations**
- **Security improvements**
- **Bug fixes**
- **Documentation updates**

### Medium Priority
- **New features**
- **Code refactoring**
- **Testing improvements**
- **Build system enhancements**

### Low Priority
- **Cosmetic changes**
- **Minor documentation fixes**
- **Code style improvements**

## 📋 Pull Request Guidelines

### Before Submitting

1. **Test thoroughly** on your local machine
2. **Follow coding standards**
3. **Update documentation** if needed
4. **Add tests** for new features
5. **Check for memory leaks**

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Security enhancement

## Testing
- [ ] Code compiles without warnings
- [ ] All tests pass
- [ ] Manual testing completed
- [ ] No memory leaks detected

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] No breaking changes
```

## 🚀 Getting Help

- **Issues**: Use GitHub Issues for bug reports and feature requests
- **Discussions**: Use GitHub Discussions for questions and ideas
- **Wiki**: Check the project wiki for detailed documentation

## 📄 License

By contributing to WizNet, you agree that your contributions will be licensed under the MIT License.

## 🙏 Recognition

Contributors will be recognized in:
- Project README
- Release notes
- Contributor hall of fame

Thank you for contributing to WizNet! 🚀 