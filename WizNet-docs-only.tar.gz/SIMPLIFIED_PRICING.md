# WizChat Simplified Pricing Model

## Overview

WizChat now uses a simplified pricing model with just two tiers:

### Free Tier ($0/month)
- Up to 5 peer connections
- 3 channels maximum
- Basic mesh networking
- Standard encryption
- No message retention
- No internet sharing
- No priority routing

### Premium Tier ($4.99/month)
- **Unlimited peer connections**
- **Unlimited channels**
- **365-day message retention**
- **Priority routing**
- **Internet sharing**
- **Advanced encryption**
- **Private Tor networks**
- **Custom domains**
- **All Enterprise features**
- **Priority support**

## Why This Change?

### Simplicity
- **One price for everything**: No confusion about which tier to choose
- **Clear value proposition**: $4.99 gets you all features
- **Easy decision**: Free or Premium - that's it

### Better Value
- **Everything included**: No more feature fragmentation
- **Enterprise features for everyone**: Private Tor networks, custom domains
- **Affordable**: $4.99 is accessible to most users
- **No upsells**: What you see is what you get

### Technical Benefits
- **Simplified codebase**: Fewer subscription tiers to manage
- **Easier testing**: Only two states to test
- **Reduced complexity**: No tier-specific feature gates
- **Better user experience**: No feature confusion

## Implementation Changes

### Product IDs
- **Apple App Store**: `wizchat.premium.monthly`, `wizchat.premium.yearly`
- **Google Play**: `wizchat.premium.monthly`, `wizchat.premium.yearly`

### Subscription Tiers
```swift
enum SubscriptionTier: String, CaseIterable {
    case free = "free"
    case premium = "premium"
}
```

### Feature Access
- **Free**: Basic mesh networking only
- **Premium**: Everything unlocked

## Revenue Impact

### Monthly Revenue per User
- **Free**: $0.00
- **Premium**: $4.99

### After Platform Fees (30%)
- **Apple/Google**: $1.50
- **Your Revenue**: $3.49

### Yearly Option
- **Premium Yearly**: $49.99/year
- **After Platform Fees**: $34.99/year
- **Monthly Equivalent**: $2.92/month

## Migration Strategy

### Existing Users
- **Free users**: No change
- **Pro users**: Automatically upgraded to Premium
- **Enterprise users**: Automatically upgraded to Premium

### App Store Updates
1. Update product IDs in App Store Connect
2. Update product IDs in Google Play Console
3. Release app updates with new pricing
4. Handle subscription migrations

### Code Changes
- [x] Updated subscription service files
- [x] Updated mobile app subscription managers
- [x] Updated browser extension
- [x] Updated web dashboard
- [x] Updated documentation

## Benefits

### For Users
- **Simpler choice**: Free or Premium
- **Better value**: All features for $4.99
- **No confusion**: Clear feature set
- **Affordable**: Accessible pricing

### For Development
- **Easier maintenance**: Fewer code paths
- **Simpler testing**: Two tiers instead of three
- **Reduced complexity**: Less feature gating
- **Faster development**: Focus on features, not tiers

### For Business
- **Higher conversion**: Clear value proposition
- **Lower support**: Fewer tier-related questions
- **Better retention**: Users get everything they need
- **Simplified analytics**: Two user segments

## Next Steps

1. **Update App Store listings** with new pricing
2. **Test subscription flow** with new product IDs
3. **Update marketing materials** to reflect new pricing
4. **Monitor conversion rates** and user feedback
5. **Consider yearly discount** to increase LTV

## Conclusion

The simplified $4.99/month pricing model makes WizChat more accessible, easier to understand, and provides better value to users while simplifying the codebase and business model. 