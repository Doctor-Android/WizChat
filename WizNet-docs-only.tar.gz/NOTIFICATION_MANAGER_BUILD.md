# Notification Manager Build Guide

This guide explains how to build the NotificationManager into standalone executables for different platforms.

## Overview

The NotificationManager has been extracted into a standalone executable that can be compiled for:
- **Linux**: `notification_manager_linux` (binary)
- **Windows**: `notification_manager.exe` 
- **macOS**: `notification_manager_macos` (binary)

## Quick Build

### Linux/macOS
```bash
# Make build script executable (if not already)
chmod +x scripts/build-notification-manager.sh

# Build for all platforms
./scripts/build-notification-manager.sh
```

### Windows
```cmd
# Run the Windows build script
scripts\build-notification-manager.bat
```

## Manual Build Commands

### Linux
```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic \
    -o build/notification_manager_linux \
    src/ui/notification_manager_standalone.cpp
```

### Windows (MinGW)
```cmd
g++ -std=c++17 -O2 -Wall -Wextra -pedantic \
    -o build/notification_manager.exe \
    src/ui/notification_manager_standalone.cpp
```

### Windows (Visual Studio)
```cmd
cl /std:c++17 /O2 /W3 /EHsc /Fe:build\notification_manager.exe \
    src\ui\notification_manager_standalone.cpp
```

### macOS
```bash
clang++ -std=c++17 -O2 -Wall -Wextra -pedantic \
    -o build/notification_manager_macos \
    src/ui/notification_manager_standalone.cpp
```

## Cross-Compilation

### Windows from Linux
```bash
# Install MinGW cross-compiler
sudo apt-get install mingw-w64

# Build Windows executable
x86_64-w64-mingw32-g++ -std=c++17 -O2 -Wall -Wextra -pedantic \
    -o build/notification_manager.exe \
    src/ui/notification_manager_standalone.cpp
```

## Testing

Run the test script to verify all executables work:
```bash
./scripts/test-notification-manager.sh
```

Or test manually:
```bash
# Linux
./build/notification_manager_linux "Test message"

# Windows (with Wine on Linux)
wine build/notification_manager.exe "Test message"

# macOS
./build/notification_manager_macos "Test message"
```

## Using CMake

You can also build using CMake:
```bash
cd src/ui
mkdir build && cd build
cmake -f ../CMakeLists_notification_manager.txt ..
make
```

## Dependencies

- **Linux**: g++ compiler
- **Windows**: Visual Studio Build Tools or MinGW
- **macOS**: Xcode Command Line Tools (clang++)
- **Cross-compilation**: mingw-w64 for Windows builds from Linux

## Output Files

After building, you'll find these files in the `build/` directory:
- `notification_manager_linux` - Linux executable
- `notification_manager.exe` - Windows executable  
- `notification_manager_macos` - macOS executable

## Troubleshooting

### Missing compiler
- **Linux**: `sudo apt-get install build-essential`
- **Windows**: Install Visual Studio Build Tools or MinGW
- **macOS**: `xcode-select --install`

### Cross-compilation issues
- Install mingw-w64: `sudo apt-get install mingw-w64`
- For ARM builds, use appropriate cross-compiler toolchains

### Permission denied
```bash
chmod +x scripts/build-notification-manager.sh
chmod +x scripts/test-notification-manager.sh
``` 