# WizNet Monetization System

A comprehensive, cross-platform monetization system for desktop applications with Stripe/Paddle integration, license management, and premium features.

## 🚀 Features

### ✅ Core Functionality
- **License Management**: Automatic license checking and validation
- **Payment Processing**: Stripe/Paddle checkout integration (demo mode)
- **Premium Features**: Feature gating based on license status
- **Support Developer**: Ko-fi, PayPal, Bitcoin donation integration
- **Ad System**: Local HTML ads for non-premium users
- **Cross-Platform**: Works with any desktop framework

### 🎨 UI Components
- **Upgrade Button**: Dynamic button that changes based on license status
- **Premium Features List**: Visual display of available/locked features
- **Support Developer Section**: Multiple donation options
- **Ad Slot**: Embedded ads for non-premium users
- **Complete UI**: Full HTML page with all components

### 🔧 Technical Features
- **C Interface**: Clean C API for any framework integration
- **Offline Support**: Works without internet once licensed
- **Demo Mode**: Test keys and simulated payments
- **Framework Agnostic**: Works with Electron, Tauri, Qt, GTK, etc.

## 📦 Installation

### Prerequisites
```bash
# Install dependencies
sudo apt-get install libcrypto++-dev libjsoncpp-dev  # Ubuntu/Debian
brew install cryptopp jsoncpp                        # macOS
```

### Build
```bash
# Build the monetization system
mkdir build && cd build
cmake ..
make monetization_demo

# Run demo
./monetization_demo
```

## 🔌 Integration

### 1. Include Headers
```cpp
#include "monetization_system.h"
#include "monetization_ui.h"
```

### 2. Check License Status
```cpp
bool isPremium = wiznet_is_premium();
if (isPremium) {
    // Enable premium features
    enableHighQualityImages();
    enableExtendedHistory();
}
```

### 3. Handle Payment Flow
```cpp
// Get upgrade URL
const char* upgradeUrl = wiznet_get_upgrade_url();

// Process payment after successful checkout
bool success = wiznet_process_payment(sessionId);
if (success) {
    // License saved, premium features enabled
    refreshUI();
}
```

### 4. Display UI Components
```cpp
// Get HTML components
const char* upgradeButton = wiznet_get_upgrade_button_html();
const char* premiumFeatures = wiznet_get_premium_features_html();
const char* supportDeveloper = wiznet_get_support_developer_html();
const char* adSlot = wiznet_get_ad_slot_html();

// Load in WebView
webView->loadHtml(upgradeButton);
```

## 🎯 Framework Examples

### Electron/Tauri
```javascript
const { BrowserWindow } = require('electron');

function createMonetizationWindow() {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    });
    
    // Load monetization UI
    win.loadFile('monetization_demo.html');
    
    // Handle payment callbacks
    win.webContents.on('ipc-message', (event, channel, data) => {
        if (channel === 'payment_success') {
            // Process payment
            console.log('Payment successful:', data);
        }
    });
}
```

### Qt
```cpp
#include <QWebEngineView>
#include "monetization_system.h"

class MonetizationWidget : public QWidget {
    Q_OBJECT
    
public:
    MonetizationWidget(QWidget *parent = nullptr) : QWidget(parent) {
        QVBoxLayout *layout = new QVBoxLayout(this);
        
        QWebEngineView *webView = new QWebEngineView(this);
        webView->setHtml(QString::fromStdString(wiznet_get_complete_ui_html()));
        
        // Connect JavaScript signals
        connect(webView->page(), &QWebEnginePage::javaScriptConsoleMessage,
                this, &MonetizationWidget::handleConsoleMessage);
        
        layout->addWidget(webView);
    }
    
private slots:
    void handleConsoleMessage(int level, const QString &message) {
        if (message.contains("payment_success")) {
            QString sessionId = message.split(":").last();
            wiznet_process_payment(sessionId.toStdString().c_str());
        }
    }
};
```

### GTK
```c
#include <gtk/gtk.h>
#include <webkit2/webkit2.h>
#include "monetization_system.h"

static void handle_console_message(WebKitWebView *web_view, 
                                 WebKitConsoleMessage *message, 
                                 gpointer user_data) {
    const char *text = webkit_console_message_get_text(message);
    
    if (g_strrstr(text, "payment_success")) {
        g_print("Payment successful: %s\n", text);
        wiznet_process_payment("cs_demo_success");
    }
}

static void create_monetization_window() {
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "WizNet Monetization");
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);
    
    GtkWidget *web_view = webkit_web_view_new();
    
    // Load monetization UI
    const char *html = wiznet_get_complete_ui_html();
    webkit_web_view_load_html(web_view, html, NULL);
    
    // Connect console message handler
    g_signal_connect(web_view, "console-message", 
                    G_CALLBACK(handle_console_message), NULL);
    
    gtk_container_add(GTK_CONTAINER(window), web_view);
    gtk_widget_show_all(window);
}
```

## 🎨 UI Components

### Upgrade Button
```html
<div class="upgrade-button" onclick="handleUpgrade()">
    <span class="icon">⭐</span>
    <span class="text">Upgrade to Pro</span>
    <span class="price">$4.99/month</span>
</div>
```

### Premium Features
```html
<div class="premium-features">
    <div class="feature">
        <span class="icon">✅</span>
        <span class="name">High-Quality Images</span>
        <span class="status">Available</span>
    </div>
    <!-- More features... -->
</div>
```

### Support Developer
```html
<div class="support-developer">
    <h3>Support the Developer</h3>
    <div class="support-buttons">
        <a href="https://ko-fi.com/wiznet" class="support-button ko-fi">
            <span class="icon">☕</span>
            <span class="text">Buy me a coffee</span>
        </a>
        <!-- More options... -->
    </div>
</div>
```

## 🔧 API Reference

### License Management
```cpp
// Check if user has premium license
bool wiznet_is_premium();

// Get upgrade URL for payment processing
const char* wiznet_get_upgrade_url();

// Process payment after successful checkout
bool wiznet_process_payment(const char* session_id);
```

### Premium Features
```cpp
// Check premium feature availability
bool wiznet_can_send_high_quality_images();
bool wiznet_can_access_extended_history();
bool wiznet_can_use_advanced_analytics();
bool wiznet_can_use_custom_themes();
bool wiznet_has_priority_support();
```

### Support Developer
```cpp
// Get support URLs
const char* wiznet_get_support_url();      // Ko-fi
const char* wiznet_get_paypal_url();       // PayPal
const char* wiznet_get_bitcoin_address();  // Bitcoin
```

### Ad System
```cpp
// Ad management
const char* wiznet_get_ad_html();
bool wiznet_are_ads_enabled();
void wiznet_disable_ads();
```

### UI Components
```cpp
// Get UI HTML components
const char* wiznet_get_upgrade_button_html();
const char* wiznet_get_premium_features_html();
const char* wiznet_get_support_developer_html();
const char* wiznet_get_ad_slot_html();
const char* wiznet_get_complete_ui_html();

// Get styling
const char* wiznet_get_ui_css();
const char* wiznet_get_ui_javascript();
```

## 🎯 Premium Features

### Available Features
- **High-Quality Images**: Send images in maximum quality
- **Extended Chat History**: Access to full message history
- **Advanced Analytics**: Detailed usage statistics
- **Custom Themes**: Personalize app appearance
- **Priority Support**: Faster customer support

### Feature Gating
```cpp
// Check before enabling premium features
if (wiznet_can_send_high_quality_images()) {
    enableHighQualityImageUpload();
}

if (wiznet_can_access_extended_history()) {
    loadFullChatHistory();
}
```

## 💳 Payment Integration

### Stripe/Paddle Setup
1. **Demo Mode**: Uses test keys and simulated payments
2. **Production**: Replace demo keys with real API keys
3. **Webhook Handling**: Process payment confirmations
4. **License Generation**: Automatic license key creation

### Payment Flow
1. User clicks "Upgrade to Pro"
2. Opens Stripe/Paddle checkout window
3. User completes payment
4. Webhook confirms payment
5. License key generated and saved
6. Premium features enabled

## 🔒 Security

### License Validation
- **Cryptographic Signing**: License keys are cryptographically signed
- **Offline Validation**: Works without internet connection
- **Tamper Detection**: Prevents license key modification
- **Expiration Handling**: Automatic license expiration checking

### Demo Keys
```cpp
// Demo license key for testing
const std::string DEMO_LICENSE_KEY = "WIZNET-PRO-2024-DEMO-KEY";

// Demo API keys
apiKey = "pk_test_51ABC123DEF456GHI789JKL012MNO345PQR678STU901VWX234YZA567BCD890";
```

## 🧪 Testing

### Demo Application
```bash
# Build and run demo
make monetization_demo
./monetization_demo
```

### Generated Files
- `monetization_demo.html`: Complete UI demo
- `monetization_styles.css`: CSS styles
- `monetization_script.js`: JavaScript functions
- `electron_integration.js`: Electron example
- `qt_integration.cpp`: Qt example
- `gtk_integration.c`: GTK example

## 📁 File Structure

```
src/
├── core/
│   └── monetization_system.cpp    # Core monetization logic
├── ui/
│   └── monetization_ui.cpp        # UI components
└── monetization_demo.cpp          # Demo application

include/
├── core/
│   └── monetization_system.h      # Core API header
└── ui/
    └── monetization_ui.h          # UI API header
```

## 🚀 Quick Start

### 1. Build the System
```bash
mkdir build && cd build
cmake ..
make monetization_demo
```

### 2. Run Demo
```bash
./monetization_demo
```

### 3. Integrate into Your App
```cpp
#include "monetization_system.h"

// Check license
if (wiznet_is_premium()) {
    enablePremiumFeatures();
}

// Display upgrade button
webView->loadHtml(wiznet_get_upgrade_button_html());
```

## 🤝 Support

### Documentation
- **API Reference**: Complete function documentation
- **Integration Guides**: Framework-specific examples
- **Demo Application**: Working example implementation

### Community
- **GitHub Issues**: Report bugs and request features
- **Discussions**: Ask questions and share ideas
- **Contributions**: Submit pull requests and improvements

## 📄 License

This monetization system is part of WizNet and is licensed under the MIT License. See LICENSE file for details.

---

**Made with ❤️ for the open source community** 