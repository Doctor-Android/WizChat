# WizNet Platform Priority Strategy

## Platform Priority Order

### 1. Linux (Primary Platform)
- **Arch-based systems** (Arch Linux, Manjaro, EndeavourOS) - Primary target
- **RedHat-based** (Fedora, RHEL, CentOS) - Secondary Linux target
- **Debian-based** (Ubuntu, Debian, Linux Mint) - Secondary Linux target

### 2. Windows/Mac (Secondary Platforms)
- Windows 10/11 desktop applications
- macOS desktop applications
- Cross-platform compatibility layer

### 3. Android (Tertiary Platform)
- Mobile companion app
- Simplified feature set
- Ads-only monetization (open source)

### 4. iOS (Fourth Priority)
- Mobile companion app
- Minimal feature set
- App Store compliance

## Development Strategy

### Linux-First Architecture
- Core services developed on Linux (Arch-based)
- Native Linux performance and integration
- Systemd integration for service management
- Package manager integration (pacman, yay, paru)
- Terminal-first interface with GUI options

### Cross-Platform Considerations
- Shared core libraries
- Platform-specific UI layers
- Progressive feature degradation
- Open source licensing

### Build System Priority
1. **Linux builds** (CMake, Make)
2. **Cross-platform builds** (Qt, GTK)
3. **Android builds** (Gradle)
4. **iOS builds** (Xcode)

## Implementation Plan

### Phase 1: Linux Core (Current)
- [x] Remove subscription dependencies
- [x] Open source Android app
- [ ] Linux-native core services
- [ ] Arch package integration
- [ ] Systemd service files

### Phase 2: Cross-Platform Expansion
- [ ] Windows/Mac desktop apps
- [ ] Shared core libraries
- [ ] Platform-specific optimizations

### Phase 3: Mobile Platforms
- [ ] Android app refinement
- [ ] iOS app development
- [ ] Mobile-specific features

## Technical Stack

### Linux (Primary)
- **Language**: C++/Rust for core services
- **UI**: Qt/GTK for desktop
- **Package**: AUR packages, systemd services
- **Build**: CMake, Make

### Cross-Platform
- **Language**: C++/Rust core, platform-specific UI
- **UI**: Qt for desktop, native mobile
- **Build**: CMake for desktop, platform-specific for mobile

### Mobile
- **Android**: Kotlin/Java, Jetpack Compose
- **iOS**: Swift, SwiftUI
- **Build**: Gradle, Xcode 