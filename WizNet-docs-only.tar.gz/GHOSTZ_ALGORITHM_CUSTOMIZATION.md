# Ghostz Algorithm Customization System

## Overview

Ghostz provides **complete algorithm customization** where users can modify, tune, and create their own algorithms. Every algorithm is customizable through visual builders, parameter tuning, and custom code creation.

## Core Customization Principles

### 1. **Visual Algorithm Builder**
- Drag-and-drop interface for algorithm creation
- No coding required for basic customizations
- Visual flow diagrams for algorithm logic

### 2. **Parameter Tuning Interface**
- Real-time parameter adjustment
- Live preview of algorithm changes
- A/B testing capabilities

### 3. **Custom Code Creation**
- Full access to algorithm source code
- Custom algorithm development
- Community algorithm sharing

## Algorithm Customization Implementation

### 1. **Visual Algorithm Builder**

```swift
// VisualAlgorithmBuilder.swift
class VisualAlgorithmBuilder: ObservableObject {
    @Published var algorithmFlow: [AlgorithmNode] = []
    @Published var availableNodes: [AlgorithmNode] = []
    @Published var customAlgorithms: [CustomAlgorithm] = []
    
    // Visual node types for algorithm building
    enum NodeType {
        case condition      // If/Then logic
        case calculation    // Mathematical operations
        case comparison     // Compare values
        case action         // Execute action
        case loop           // Repeat logic
        case function       // Custom function
    }
    
    struct AlgorithmNode: Identifiable {
        let id = UUID()
        var type: NodeType
        var parameters: [String: Any]
        var connections: [UUID] = []
        var position: CGPoint
        var label: String
    }
    
    func createCustomAlgorithm(name: String, flow: [AlgorithmNode]) -> CustomAlgorithm {
        let algorithm = CustomAlgorithm(
            name: name,
            flow: flow,
            code: generateCode(from: flow),
            isActive: true
        )
        
        customAlgorithms.append(algorithm)
        saveCustomAlgorithm(algorithm)
        
        return algorithm
    }
    
    private func generateCode(from flow: [AlgorithmNode]) -> String {
        // Convert visual flow to executable code
        var code = "func customAlgorithm() -> Bool {\n"
        
        for node in flow {
            switch node.type {
            case .condition:
                code += "    if \(node.parameters["condition"] as? String ?? "") {\n"
                code += "        return \(node.parameters["result"] as? Bool ?? true)\n"
                code += "    }\n"
                
            case .calculation:
                code += "    let result = \(node.parameters["formula"] as? String ?? "")\n"
                
            case .comparison:
                code += "    if \(node.parameters["left"] as? String ?? "") \(node.parameters["operator"] as? String ?? "==") \(node.parameters["right"] as? String ?? "") {\n"
                code += "        \(node.parameters["action"] as? String ?? "")\n"
                code += "    }\n"
                
            case .action:
                code += "    \(node.parameters["action"] as? String ?? "")\n"
                
            case .loop:
                code += "    for _ in 0..<\(node.parameters["iterations"] as? Int ?? 1) {\n"
                code += "        \(node.parameters["loopBody"] as? String ?? "")\n"
                code += "    }\n"
                
            case .function:
                code += "    \(node.parameters["functionCall"] as? String ?? "")\n"
            }
        }
        
        code += "    return true\n}"
        return code
    }
}
```

### 2. **Parameter Tuning Interface**

```swift
// ParameterTuner.swift
class ParameterTuner: ObservableObject {
    @Published var algorithmParameters: [String: AlgorithmParameter] = [:]
    @Published var activeAlgorithm: String = ""
    @Published var parameterHistory: [ParameterChange] = []
    
    struct AlgorithmParameter {
        let name: String
        let type: ParameterType
        var value: Any
        let minValue: Any?
        let maxValue: Any?
        let description: String
        let unit: String?
        
        enum ParameterType {
            case integer
            case double
            case boolean
            case string
            case array
            case custom
        }
    }
    
    func tuneParameter(_ parameterName: String, newValue: Any) {
        guard var parameter = algorithmParameters[parameterName] else { return }
        
        // Validate parameter value
        if let validatedValue = validateParameter(parameter, newValue) {
            // Log parameter change
            let change = ParameterChange(
                parameter: parameterName,
                oldValue: parameter.value,
                newValue: validatedValue,
                timestamp: Date()
            )
            parameterHistory.append(change)
            
            // Update parameter
            parameter.value = validatedValue
            algorithmParameters[parameterName] = parameter
            
            // Apply change to algorithm
            applyParameterChange(parameterName, validatedValue)
            
            // Notify user of change
            notifyParameterChange(change)
        }
    }
    
    private func validateParameter(_ parameter: AlgorithmParameter, _ newValue: Any) -> Any? {
        switch parameter.type {
        case .integer:
            guard let intValue = newValue as? Int else { return nil }
            if let min = parameter.minValue as? Int, intValue < min { return nil }
            if let max = parameter.maxValue as? Int, intValue > max { return nil }
            return intValue
            
        case .double:
            guard let doubleValue = newValue as? Double else { return nil }
            if let min = parameter.maxValue as? Double, doubleValue < min { return nil }
            if let max = parameter.maxValue as? Double, doubleValue > max { return nil }
            return doubleValue
            
        case .boolean:
            return newValue as? Bool
            
        case .string:
            return newValue as? String
            
        case .array:
            return newValue as? [Any]
            
        case .custom:
            return newValue
        }
    }
    
    private func applyParameterChange(_ parameterName: String, _ newValue: Any) {
        // Apply parameter change to running algorithm
        switch activeAlgorithm {
        case "WiFiSharing":
            updateWiFiSharingParameter(parameterName, newValue)
        case "AddictionPrevention":
            updateAddictionPreventionParameter(parameterName, newValue)
        case "MeshRouting":
            updateMeshRoutingParameter(parameterName, newValue)
        case "AdminDecision":
            updateAdminDecisionParameter(parameterName, newValue)
        default:
            updateCustomAlgorithmParameter(activeAlgorithm, parameterName, newValue)
        }
    }
}
```

### 3. **Custom Algorithm Creation**

```swift
// CustomAlgorithmCreator.swift
class CustomAlgorithmCreator: ObservableObject {
    @Published var customAlgorithms: [CustomAlgorithm] = []
    @Published var algorithmTemplates: [AlgorithmTemplate] = []
    @Published var sharedAlgorithms: [SharedAlgorithm] = []
    
    struct CustomAlgorithm {
        let id = UUID()
        let name: String
        let description: String
        let code: String
        let parameters: [String: Any]
        let isActive: Bool
        let createdAt: Date
        let author: String
        let version: String
        let tags: [String]
    }
    
    struct AlgorithmTemplate {
        let name: String
        let description: String
        let code: String
        let parameters: [String: Any]
        let category: String
        let difficulty: Difficulty
        
        enum Difficulty {
            case beginner
            case intermediate
            case advanced
        }
    }
    
    func createCustomAlgorithm(name: String, description: String, code: String, parameters: [String: Any]) -> CustomAlgorithm {
        let algorithm = CustomAlgorithm(
            name: name,
            description: description,
            code: code,
            parameters: parameters,
            isActive: true,
            createdAt: Date(),
            author: getCurrentUser(),
            version: "1.0.0",
            tags: []
        )
        
        // Validate algorithm code
        if validateAlgorithmCode(code) {
            customAlgorithms.append(algorithm)
            saveCustomAlgorithm(algorithm)
            
            // Register algorithm with system
            registerCustomAlgorithm(algorithm)
            
            return algorithm
        } else {
            throw AlgorithmValidationError.invalidCode
        }
    }
    
    func createFromTemplate(_ template: AlgorithmTemplate) -> CustomAlgorithm {
        return createCustomAlgorithm(
            name: "\(template.name) (Custom)",
            description: template.description,
            code: template.code,
            parameters: template.parameters
        )
    }
    
    func shareAlgorithm(_ algorithm: CustomAlgorithm) -> SharedAlgorithm {
        let shared = SharedAlgorithm(
            algorithm: algorithm,
            shareDate: Date(),
            downloads: 0,
            rating: 0.0,
            reviews: []
        )
        
        sharedAlgorithms.append(shared)
        uploadToCommunity(shared)
        
        return shared
    }
    
    private func validateAlgorithmCode(_ code: String) -> Bool {
        // Validate algorithm code for safety and correctness
        let validator = AlgorithmCodeValidator()
        return validator.validate(code)
    }
}
```

### 4. **Algorithm Code Validator**

```swift
// AlgorithmCodeValidator.swift
class AlgorithmCodeValidator {
    
    private let allowedFunctions = [
        "log", "sqrt", "pow", "abs", "min", "max",
        "getUserReputation", "getNetworkStatus", "calculateBandwidth",
        "checkTimeRestrictions", "validateInput", "logDecision"
    ]
    
    private let forbiddenKeywords = [
        "import", "class", "struct", "enum", "protocol",
        "fileprivate", "private", "internal", "public",
        "static", "mutating", "final", "override"
    ]
    
    func validate(_ code: String) -> Bool {
        // Check for forbidden keywords
        for keyword in forbiddenKeywords {
            if code.contains(keyword) {
                return false
            }
        }
        
        // Check for allowed functions only
        let functionCalls = extractFunctionCalls(from: code)
        for function in functionCalls {
            if !allowedFunctions.contains(function) {
                return false
            }
        }
        
        // Check syntax
        return validateSyntax(code)
    }
    
    private func extractFunctionCalls(from code: String) -> [String] {
        // Extract function calls from code
        let pattern = "\\b\\w+\\s*\\("
        let regex = try! NSRegularExpression(pattern: pattern)
        let matches = regex.matches(in: code, range: NSRange(code.startIndex..., in: code))
        
        return matches.map { match in
            let range = Range(match.range, in: code)!
            let functionCall = String(code[range])
            return String(functionCall.dropLast()) // Remove opening parenthesis
        }
    }
    
    private func validateSyntax(_ code: String) -> Bool {
        // Basic syntax validation
        let openBraces = code.filter { $0 == "{" }.count
        let closeBraces = code.filter { $0 == "}" }.count
        
        return openBraces == closeBraces
    }
}
```

## Visual Algorithm Builder UI

### 1. **Algorithm Builder Interface**

```swift
// AlgorithmBuilderView.swift
struct AlgorithmBuilderView: View {
    @StateObject private var builder = VisualAlgorithmBuilder()
    @State private var selectedNode: AlgorithmNode?
    @State private var showingNodeEditor = false
    
    var body: some View {
        VStack {
            // Toolbar
            HStack {
                Button("Add Condition") {
                    addNode(.condition)
                }
                Button("Add Calculation") {
                    addNode(.calculation)
                }
                Button("Add Action") {
                    addNode(.action)
                }
                Button("Add Loop") {
                    addNode(.loop)
                }
                Spacer()
                Button("Test Algorithm") {
                    testAlgorithm()
                }
                Button("Save Algorithm") {
                    saveAlgorithm()
                }
            }
            .padding()
            
            // Canvas
            ZStack {
                // Background grid
                GridBackground()
                
                // Algorithm nodes
                ForEach(builder.algorithmFlow) { node in
                    AlgorithmNodeView(node: node)
                        .position(node.position)
                        .onTapGesture {
                            selectedNode = node
                            showingNodeEditor = true
                        }
                }
                
                // Connection lines
                ConnectionLines(nodes: builder.algorithmFlow)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .sheet(isPresented: $showingNodeEditor) {
            NodeEditorView(node: $selectedNode)
        }
    }
    
    private func addNode(_ type: VisualAlgorithmBuilder.NodeType) {
        let newNode = AlgorithmNode(
            type: type,
            parameters: [:],
            position: CGPoint(x: 100, y: 100),
            label: "New \(type)"
        )
        builder.algorithmFlow.append(newNode)
    }
    
    private func testAlgorithm() {
        // Test the current algorithm
        let testResult = builder.testCurrentAlgorithm()
        showTestResults(testResult)
    }
    
    private func saveAlgorithm() {
        let algorithm = builder.createCustomAlgorithm(
            name: "Custom Algorithm",
            flow: builder.algorithmFlow
        )
        showSaveSuccess(algorithm)
    }
}

struct AlgorithmNodeView: View {
    let node: VisualAlgorithmBuilder.AlgorithmNode
    
    var body: some View {
        VStack {
            Image(systemName: iconName)
                .font(.title2)
            Text(node.label)
                .font(.caption)
        }
        .padding()
        .background(backgroundColor)
        .cornerRadius(8)
        .shadow(radius: 2)
    }
    
    private var iconName: String {
        switch node.type {
        case .condition: return "questionmark.circle"
        case .calculation: return "plus.circle"
        case .comparison: return "equal.circle"
        case .action: return "play.circle"
        case .loop: return "arrow.clockwise.circle"
        case .function: return "function.circle"
        }
    }
    
    private var backgroundColor: Color {
        switch node.type {
        case .condition: return .blue
        case .calculation: return .green
        case .comparison: return .orange
        case .action: return .red
        case .loop: return .purple
        case .function: return .gray
        }
    }
}
```

### 2. **Parameter Tuning Interface**

```swift
// ParameterTuningView.swift
struct ParameterTuningView: View {
    @StateObject private var tuner = ParameterTuner()
    @State private var selectedAlgorithm = "WiFiSharing"
    @State private var showingParameterHistory = false
    
    var body: some View {
        VStack {
            // Algorithm selector
            Picker("Algorithm", selection: $selectedAlgorithm) {
                Text("WiFi Sharing").tag("WiFiSharing")
                Text("Addiction Prevention").tag("AddictionPrevention")
                Text("Mesh Routing").tag("MeshRouting")
                Text("Admin Decision").tag("AdminDecision")
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            
            // Parameter sliders
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(Array(tuner.algorithmParameters.keys.sorted()), id: \.self) { key in
                        if let parameter = tuner.algorithmParameters[key] {
                            ParameterSliderView(parameter: parameter) { newValue in
                                tuner.tuneParameter(key, newValue: newValue)
                            }
                        }
                    }
                }
                .padding()
            }
            
            // Live preview
            AlgorithmPreviewView(algorithm: selectedAlgorithm)
        }
        .navigationTitle("Algorithm Tuning")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("History") {
                    showingParameterHistory = true
                }
            }
        }
        .sheet(isPresented: $showingParameterHistory) {
            ParameterHistoryView(history: tuner.parameterHistory)
        }
    }
}

struct ParameterSliderView: View {
    let parameter: ParameterTuner.AlgorithmParameter
    let onValueChange: (Any) -> Void
    
    @State private var currentValue: Any
    
    init(parameter: ParameterTuner.AlgorithmParameter, onValueChange: @escaping (Any) -> Void) {
        self.parameter = parameter
        self.onValueChange = onValueChange
        self._currentValue = State(initialValue: parameter.value)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(parameter.name)
                    .font(.headline)
                Spacer()
                Text("\(formatValue(currentValue)) \(parameter.unit ?? "")")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            switch parameter.type {
            case .integer:
                Slider(
                    value: Binding(
                        get: { currentValue as? Double ?? 0 },
                        set: { 
                            currentValue = Int($0)
                            onValueChange(currentValue)
                        }
                    ),
                    in: (parameter.minValue as? Double ?? 0)...(parameter.maxValue as? Double ?? 100)
                )
                
            case .double:
                Slider(
                    value: Binding(
                        get: { currentValue as? Double ?? 0 },
                        set: { 
                            currentValue = $0
                            onValueChange(currentValue)
                        }
                    ),
                    in: (parameter.minValue as? Double ?? 0)...(parameter.maxValue as? Double ?? 100)
                )
                
            case .boolean:
                Toggle("", isOn: Binding(
                    get: { currentValue as? Bool ?? false },
                    set: { 
                        currentValue = $0
                        onValueChange(currentValue)
                    }
                ))
                
            case .string:
                TextField("Value", text: Binding(
                    get: { currentValue as? String ?? "" },
                    set: { 
                        currentValue = $0
                        onValueChange(currentValue)
                    }
                ))
                
            default:
                Text("Custom parameter type")
                    .foregroundColor(.secondary)
            }
            
            Text(parameter.description)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(8)
    }
    
    private func formatValue(_ value: Any) -> String {
        switch value {
        case let int as Int: return "\(int)"
        case let double as Double: return String(format: "%.2f", double)
        case let bool as Bool: return bool ? "Yes" : "No"
        case let string as String: return string
        default: return "\(value)"
        }
    }
}
```

### 3. **Custom Algorithm Creator**

```swift
// CustomAlgorithmCreatorView.swift
struct CustomAlgorithmCreatorView: View {
    @StateObject private var creator = CustomAlgorithmCreator()
    @State private var algorithmName = ""
    @State private var algorithmDescription = ""
    @State private var algorithmCode = ""
    @State private var showingTemplates = false
    @State private var showingSharedAlgorithms = false
    
    var body: some View {
        NavigationView {
            VStack {
                // Algorithm info
                VStack(alignment: .leading, spacing: 16) {
                    TextField("Algorithm Name", text: $algorithmName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Description", text: $algorithmDescription, axis: .vertical)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .lineLimit(3...6)
                }
                .padding()
                
                // Code editor
                CodeEditorView(code: $algorithmCode)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                // Action buttons
                HStack {
                    Button("Load Template") {
                        showingTemplates = true
                    }
                    
                    Button("Browse Community") {
                        showingSharedAlgorithms = true
                    }
                    
                    Spacer()
                    
                    Button("Test Code") {
                        testAlgorithmCode()
                    }
                    
                    Button("Create Algorithm") {
                        createAlgorithm()
                    }
                    .disabled(algorithmName.isEmpty || algorithmCode.isEmpty)
                }
                .padding()
            }
            .navigationTitle("Create Custom Algorithm")
            .sheet(isPresented: $showingTemplates) {
                AlgorithmTemplatesView(templates: creator.algorithmTemplates)
            }
            .sheet(isPresented: $showingSharedAlgorithms) {
                SharedAlgorithmsView(algorithms: creator.sharedAlgorithms)
            }
        }
    }
    
    private func testAlgorithmCode() {
        let validator = AlgorithmCodeValidator()
        let isValid = validator.validate(algorithmCode)
        
        if isValid {
            showAlert("Code Valid", "Your algorithm code is valid and ready to use!")
        } else {
            showAlert("Code Invalid", "Please check your algorithm code for errors.")
        }
    }
    
    private func createAlgorithm() {
        do {
            let algorithm = try creator.createCustomAlgorithm(
                name: algorithmName,
                description: algorithmDescription,
                code: algorithmCode,
                parameters: [:]
            )
            
            showAlert("Success", "Custom algorithm '\(algorithm.name)' created successfully!")
            
            // Reset form
            algorithmName = ""
            algorithmDescription = ""
            algorithmCode = ""
            
        } catch {
            showAlert("Error", "Failed to create algorithm: \(error.localizedDescription)")
        }
    }
}

struct CodeEditorView: View {
    @Binding var code: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Algorithm Code")
                .font(.headline)
                .padding(.horizontal)
            
            TextEditor(text: $code)
                .font(.system(.body, design: .monospaced))
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal)
        }
    }
}
```

## Algorithm Templates

### 1. **Pre-built Templates**

```swift
// AlgorithmTemplates.swift
struct AlgorithmTemplates {
    static let templates: [CustomAlgorithmCreator.AlgorithmTemplate] = [
        // WiFi Sharing Templates
        AlgorithmTemplate(
            name: "Strict WiFi Sharing",
            description: "Only share WiFi with high-reputation users during business hours",
            code: """
            func strictWiFiSharing() -> Bool {
                let reputation = getUserReputation(requester)
                let hour = Calendar.current.component(.hour, from: Date())
                
                if reputation < 0.8 {
                    logDecision("WiFi denied: Low reputation")
                    return false
                }
                
                if hour < 9 || hour > 17 {
                    logDecision("WiFi denied: Outside business hours")
                    return false
                }
                
                logDecision("WiFi approved: All criteria met")
                return true
            }
            """,
            parameters: ["minReputation": 0.8, "startHour": 9, "endHour": 17],
            category: "WiFi Sharing",
            difficulty: .beginner
        ),
        
        // Addiction Prevention Templates
        AlgorithmTemplate(
            name: "Progressive Time Limits",
            description: "Gradually reduce time limits for heavy users",
            code: """
            func progressiveTimeLimits() -> TimeInterval {
                let dailyUsage = getDailyUsage()
                let baseLimit = 3600 // 1 hour
                
                if dailyUsage > 4 {
                    return baseLimit * 0.5 // 50% for heavy users
                } else if dailyUsage > 2 {
                    return baseLimit * 0.75 // 75% for moderate users
                } else {
                    return baseLimit // Full limit for light users
                }
            }
            """,
            parameters: ["baseLimit": 3600, "heavyUsageThreshold": 4, "moderateUsageThreshold": 2],
            category: "Addiction Prevention",
            difficulty: .intermediate
        ),
        
        // Mesh Routing Templates
        AlgorithmTemplate(
            name: "Reliability-First Routing",
            description: "Prioritize reliable nodes in mesh routing",
            code: """
            func reliabilityFirstRouting() -> [String] {
                let nodes = getAvailableNodes()
                let reliableNodes = nodes.filter { $0.reliability > 0.8 }
                
                if reliableNodes.isEmpty {
                    return nodes.map { $0.id }
                } else {
                    return reliableNodes.map { $0.id }
                }
            }
            """,
            parameters: ["minReliability": 0.8],
            category: "Mesh Routing",
            difficulty: .advanced
        )
    ]
}
```

### 2. **Community Algorithm Sharing**

```swift
// CommunityAlgorithmSharing.swift
class CommunityAlgorithmSharing: ObservableObject {
    @Published var sharedAlgorithms: [SharedAlgorithm] = []
    @Published var userRatings: [String: Double] = [:]
    @Published var userReviews: [String: [Review]] = [:]
    
    struct SharedAlgorithm {
        let id = UUID()
        let algorithm: CustomAlgorithmCreator.CustomAlgorithm
        let shareDate: Date
        var downloads: Int
        var rating: Double
        var reviews: [Review]
        let tags: [String]
        let difficulty: CustomAlgorithmCreator.AlgorithmTemplate.Difficulty
    }
    
    struct Review {
        let author: String
        let rating: Int
        let comment: String
        let date: Date
    }
    
    func shareAlgorithm(_ algorithm: CustomAlgorithmCreator.CustomAlgorithm) {
        let shared = SharedAlgorithm(
            algorithm: algorithm,
            shareDate: Date(),
            downloads: 0,
            rating: 0.0,
            reviews: [],
            tags: algorithm.tags,
            difficulty: .intermediate
        )
        
        sharedAlgorithms.append(shared)
        uploadToCommunity(shared)
    }
    
    func downloadAlgorithm(_ algorithm: SharedAlgorithm) {
        // Download and install algorithm
        let customAlgorithm = algorithm.algorithm
        CustomAlgorithmCreator().customAlgorithms.append(customAlgorithm)
        
        // Update download count
        if let index = sharedAlgorithms.firstIndex(where: { $0.id == algorithm.id }) {
            sharedAlgorithms[index].downloads += 1
        }
    }
    
    func rateAlgorithm(_ algorithmId: String, rating: Int, comment: String) {
        let review = Review(
            author: getCurrentUser(),
            rating: rating,
            comment: comment,
            date: Date()
        )
        
        if let index = sharedAlgorithms.firstIndex(where: { $0.algorithm.id.uuidString == algorithmId }) {
            sharedAlgorithms[index].reviews.append(review)
            
            // Update average rating
            let totalRating = sharedAlgorithms[index].reviews.reduce(0) { $0 + $1.rating }
            let averageRating = Double(totalRating) / Double(sharedAlgorithms[index].reviews.count)
            sharedAlgorithms[index].rating = averageRating
        }
    }
}
```

## Real-Time Algorithm Testing

### 1. **Algorithm Testing Interface**

```swift
// AlgorithmTestingView.swift
struct AlgorithmTestingView: View {
    @State private var selectedAlgorithm = "Custom"
    @State private var testInput: String = ""
    @State private var testResults: [TestResult] = []
    @State private var isRunningTest = false
    
    struct TestResult {
        let input: String
        let output: Any
        let executionTime: TimeInterval
        let success: Bool
        let error: String?
    }
    
    var body: some View {
        VStack {
            // Algorithm selector
            Picker("Algorithm", selection: $selectedAlgorithm) {
                Text("Custom Algorithm").tag("Custom")
                Text("WiFi Sharing").tag("WiFiSharing")
                Text("Addiction Prevention").tag("AddictionPrevention")
                Text("Mesh Routing").tag("MeshRouting")
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            
            // Test input
            VStack(alignment: .leading) {
                Text("Test Input")
                    .font(.headline)
                
                TextField("Enter test parameters", text: $testInput, axis: .vertical)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .lineLimit(3...6)
            }
            .padding()
            
            // Test results
            VStack(alignment: .leading) {
                Text("Test Results")
                    .font(.headline)
                
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(testResults, id: \.input) { result in
                            TestResultRow(result: result)
                        }
                    }
                }
            }
            .padding()
            
            // Test buttons
            HStack {
                Button("Run Single Test") {
                    runSingleTest()
                }
                
                Button("Run Multiple Tests") {
                    runMultipleTests()
                }
                
                Spacer()
                
                Button("Clear Results") {
                    testResults.removeAll()
                }
            }
            .padding()
        }
        .navigationTitle("Algorithm Testing")
    }
    
    private func runSingleTest() {
        isRunningTest = true
        
        DispatchQueue.global(qos: .userInitiated).async {
            let startTime = Date()
            
            do {
                let result = try executeAlgorithm(selectedAlgorithm, with: testInput)
                let executionTime = Date().timeIntervalSince(startTime)
                
                let testResult = TestResult(
                    input: testInput,
                    output: result,
                    executionTime: executionTime,
                    success: true,
                    error: nil
                )
                
                DispatchQueue.main.async {
                    testResults.append(testResult)
                    isRunningTest = false
                }
                
            } catch {
                let executionTime = Date().timeIntervalSince(startTime)
                
                let testResult = TestResult(
                    input: testInput,
                    output: "Error",
                    executionTime: executionTime,
                    success: false,
                    error: error.localizedDescription
                )
                
                DispatchQueue.main.async {
                    testResults.append(testResult)
                    isRunningTest = false
                }
            }
        }
    }
    
    private func runMultipleTests() {
        let testCases = generateTestCases()
        
        for testCase in testCases {
            testInput = testCase
            runSingleTest()
        }
    }
}

struct TestResultRow: View {
    let result: AlgorithmTestingView.TestResult
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("Input: \(result.input)")
                    .font(.caption)
                Spacer()
                Text(String(format: "%.3fs", result.executionTime))
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if result.success {
                Text("Output: \(String(describing: result.output))")
                    .font(.caption)
                    .foregroundColor(.green)
            } else {
                Text("Error: \(result.error ?? "Unknown error")")
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(8)
    }
}
```

## Summary

Ghostz provides **complete algorithm customization** where users can:

✅ **Modify existing algorithms** through parameter tuning
✅ **Create custom algorithms** using visual builders
✅ **Write custom code** for advanced users
✅ **Share algorithms** with the community
✅ **Test algorithms** in real-time
✅ **Browse algorithm templates** for quick start
✅ **Rate and review** community algorithms
✅ **A/B test** different algorithm versions

This gives users **complete control** over how the system behaves, making Ghostz truly customizable to their preferences and needs! 