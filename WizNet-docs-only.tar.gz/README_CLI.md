# WizNet CLI - Terminal-Based Mesh Network

WizNet CLI is a powerful terminal-based interface for the WizNet decentralized mesh network. It provides all core functionality through command-line interface, making it perfect for servers, headless systems, and automation.

## Features

- **Mesh Networking**: Decentralized peer-to-peer communication
- **Tor Integration**: Anonymous browsing and network access
- **qBittorrent Management**: Torrent downloading and sharing
- **Music Player**: Local and streaming audio playback
- **Browser Control**: Launch and manage browser sessions
- **Network Scanning**: Bluetooth and WiFi device discovery
- **Chat System**: Real-time messaging across the mesh
- **Configuration Management**: Persistent settings storage

## Building

### Linux
```bash
mkdir build && cd build
cmake ..
make wiznet-cli
```

### macOS
```bash
mkdir build && cd build
cmake ..
make wiznet-cli
```

### Windows
```bash
mkdir build && cd build
cmake -G "Visual Studio 16 2019" ..
cmake --build . --target wiznet-cli
```

## Usage

### Starting WizNet CLI
```bash
./wiznet-cli
```

### Available Commands

#### Mesh Network Commands
```bash
mesh start          # Start the mesh network
mesh stop           # Stop the mesh network
mesh status         # Show mesh network status
mesh nodes          # List connected nodes
mesh send <message> # Send message to mesh network
```

#### Chat Commands
```bash
chat send <message> # Send a chat message
chat history        # Show chat history
chat clear          # Clear chat history
```

#### Tor Network Commands
```bash
tor start           # Start Tor network
tor stop            # Stop Tor network
tor status          # Show Tor status
tor ip              # Get Tor IP address
```

#### qBittorrent Commands
```bash
qbittorrent start           # Start qBittorrent
qbittorrent stop            # Stop qBittorrent
qbittorrent status          # Show qBittorrent status
qbittorrent add <url>       # Add torrent by URL
```

#### Browser Commands
```bash
browser open <url>  # Open URL in default browser
browser private     # Open private browser session
browser mesh        # Open mesh network browser
```

#### Music Commands
```bash
music play <file>           # Play music file
music stop                  # Stop music playback
music pause                 # Pause music
music resume                # Resume music
music volume <0-100>        # Set volume level
```

#### Network Commands
```bash
network scan                # Scan all networks
network bluetooth           # Scan Bluetooth devices
network wifi                # Scan WiFi networks
network interfaces          # Show network interfaces
```

#### Configuration Commands
```bash
config set <key> <value>   # Set configuration value
config get <key>            # Get configuration value
config save                 # Save configuration
config load                 # Load configuration
```

#### System Commands
```bash
status                     # Show all system status
clear                      # Clear screen
help                       # Show help
quit                       # Exit WizNet
```

## Example Usage

### Basic Setup
```bash
wiznet> mesh start
Starting mesh network on port 3001...
Mesh network started successfully

wiznet> tor start
Starting Tor network...
Tor network started

wiznet> status
=== WizNet System Status ===
Mesh Network Status:
  Active: Yes
  Port: 3001
  Connected nodes: 1

Tor Status:
  Enabled: Yes
  IP: 127.0.0.1:9050

qBittorrent Status:
  Running: No
  Port: 8080

Chat messages: 0
Config entries: 0
```

### Sending Messages
```bash
wiznet> mesh send "Hello mesh network!"
Sending mesh message: Hello mesh network!
Message sent to 1 nodes

wiznet> chat send "Hello everyone!"
Sending chat message: Hello everyone!
Message sent
```

### Network Operations
```bash
wiznet> network scan
Scanning Bluetooth devices...
Found devices:
  - Device 1 (00:11:22:33:44:55)
  - Device 2 (AA:BB:CC:DD:EE:FF)
Scanning WiFi networks...
Found networks:
  - Network1 (WPA2)
  - Network2 (Open)
```

### Browser Control
```bash
wiznet> browser open https://wiznet.org
Opening browser: https://wiznet.org

wiznet> browser mesh
Opening mesh network browser...
```

## Configuration

WizNet CLI stores configuration in `wiznet.conf`:

```bash
wiznet> config set mesh_port 3001
Config set: mesh_port = 3001

wiznet> config set tor_enabled true
Config set: tor_enabled = true

wiznet> config save
Configuration saved
```

## Community GUI Development

The CLI provides a solid foundation for GUI development:

### Integration Points
- **IPC Communication**: Use standard input/output for GUI communication
- **Configuration Files**: Shared config format between CLI and GUI
- **Network APIs**: Same network functions available to GUIs
- **Plugin System**: Modular architecture for feature extensions

### Example GUI Integration
```bash
# GUI can launch CLI in background
./wiznet-cli --gui-mode --config-file gui.conf

# GUI can parse CLI output
./wiznet-cli status --json

# GUI can send commands to CLI
echo "mesh start" | ./wiznet-cli
```

## Platform Support

### Linux
- **Ubuntu/Debian**: `apt install build-essential cmake`
- **CentOS/RHEL**: `yum install gcc-c++ cmake`
- **Arch**: `pacman -S base-devel cmake`
- **Alpine**: `apk add build-base cmake`

### macOS
- **Homebrew**: `brew install cmake`
- **Xcode**: Install Command Line Tools

### Windows
- **Visual Studio**: Install with C++ workload
- **MinGW**: `pacman -S mingw-w64-x86_64-cmake`
- **WSL**: Use Linux instructions

## Development

### Adding New Commands
1. Add command handler in `WizNetCLI::processCommand()`
2. Implement functionality in separate method
3. Update help text in `showHelp()`
4. Add to documentation

### Extending Features
- **New Protocols**: Add to mesh network layer
- **Additional Services**: Create new service classes
- **Platform APIs**: Implement platform-specific features
- **Network Protocols**: Add support for new protocols

## Troubleshooting

### Common Issues

**Build Errors**
```bash
# Missing dependencies
sudo apt install build-essential cmake

# CMake not found
sudo apt install cmake
```

**Runtime Errors**
```bash
# Permission denied
chmod +x wiznet-cli

# Port already in use
config set mesh_port 3002
```

**Network Issues**
```bash
# Firewall blocking
sudo ufw allow 3001

# Bluetooth permissions
sudo usermod -a -G bluetooth $USER
```

## License

WizNet CLI is part of the WizNet project. See LICENSE for details.

## Contributing

1. Fork the repository
2. Create feature branch
3. Add tests for new functionality
4. Submit pull request

## Support

- **Issues**: GitHub Issues
- **Documentation**: README files
- **Community**: WizNet Discord/Matrix
- **Development**: Developer documentation 